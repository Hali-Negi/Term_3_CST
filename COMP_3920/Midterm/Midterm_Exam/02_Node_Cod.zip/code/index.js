const express = require('express');

const port = process.env.PORT || 3005;

const app = express();

app.set("view engine", "ejs");

app.use(express.urlencoded({extended: false}));


app.get('/', (req,res) => {
    res.render("home");
});

app.get('/surveyStart', (req,res) => {
	var missingFields = req.query.invalid;
	if (missingFields) {
		res.render("survey", {missingFields: 1});
	}
	else {
    	res.render("survey");
	}
});

app.post('/submitSurvey', (req,res) => {
	var phoneType = req.body.phoneType; 
	var email = req.body.email;


	if (!email || !phoneType) {
		res.redirect("/surveyStart?invalid=1");
		return;	
	}

	var phoneStats = {
		iphone: 57,
		android: 43
	};  //stats according to statista.com for Canada 2022 (https://www.statista.com/statistics/1190552/smartphone-market-share-canada/)

	var percent = 0;
	if (phoneType === "iphone") {
		percent = phoneStats.iphone;

	} else if (phoneType === "android") {
		percent = phoneStats.android;
	}

	res.render("surveyResults", {percent: percent, usersPhoneType: phoneType});
});

app.get('/accessories', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/accessories/keyboards', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/accessories/mice', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/laptops', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/laptops/macs', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/laptops/windows', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/desktops', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/desktops/macs', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.get('/computers/desktops/pcs', (req, res) => {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    let folders = new URL(fullUrl).pathname.split("/").slice(1);
    res.render('page', {folders: folders});
});

app.listen(port, () => {
	console.log("Node application listening on port "+port);
}); 